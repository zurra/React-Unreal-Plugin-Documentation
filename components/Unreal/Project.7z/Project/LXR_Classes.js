const Classes = [
  {
    className: "Detection Component",
    description: "Light Detection",
  },
  {
    className: "Memory Component",
    description: "Memory state",
  }
];

export default {
  Classes,
};

